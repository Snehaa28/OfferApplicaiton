package com.cognizant.offers.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Document("elgibleTransactions")
@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class ElgibleTransactions {

	@Id
	private String id;
	private String transactionId;
	private String offerId;
	private boolean isElgible;
	public ElgibleTransactions(String transactionId, String offerId, boolean isElgible) {
		super();
		this.transactionId = transactionId;
		this.offerId = offerId;
		this.isElgible = isElgible;
	}

	

}
