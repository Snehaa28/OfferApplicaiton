package com.cognizant.offers.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document("offers")
@Data
public class Offers {

	@Id
	private String id;

	private String discount;
	private double price;
	private Date startDate;
	private Date endDate;

	public Offers(String id, String discount, double price, Date startDate, Date endDate) {
		super();
		this.id = id;
		this.discount = discount;
		this.price = price;
		this.startDate = startDate;
		this.endDate = endDate;
	}

}
