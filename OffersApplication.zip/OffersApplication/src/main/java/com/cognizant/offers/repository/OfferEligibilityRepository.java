package com.cognizant.offers.repository;

import com.cognizant.offers.model.ElgibleTransactions;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface OfferEligibilityRepository extends MongoRepository<ElgibleTransactions, String> {

	@Query("{transactionId:'?0'}")
	ElgibleTransactions findElgibleTransactionsByTransactionId(String transactionId);

}
