package com.cognizant.offers.repository;

import com.cognizant.offers.model.Offers;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface OffersRepository extends MongoRepository<Offers, String> {

}
