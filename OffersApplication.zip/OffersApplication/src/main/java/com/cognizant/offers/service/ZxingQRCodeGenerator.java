package com.cognizant.offers.service;

import java.awt.image.BufferedImage;

import com.cognizant.offers.model.Transaction;
import com.cognizant.offers.repository.OfferEligibilityRepository;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import org.springframework.beans.factory.annotation.Autowired;

public class ZxingQRCodeGenerator {

	@Autowired
	OfferEligibilityRepository elgibilityRepo;

	public BufferedImage generateQRCodeImage(Transaction transactions) throws Exception {

		QRCodeWriter barcodeWriter = new QRCodeWriter();
		BitMatrix bitMatrix = barcodeWriter.encode(getOfferData(transactions.getTransactionId()), BarcodeFormat.QR_CODE,
				200, 200);
		return MatrixToImageWriter.toBufferedImage(bitMatrix);
	}

	private String getOfferData(String transactionsId) {
		String offerId = elgibilityRepo.findElgibleTransactionsByTransactionId(transactionsId).getOfferId();
		if (offerId != null) {
			return offerId;
		} else {
			return "No Offers found for this transcation";
		}

	}

}
