package com.cognizant.offers.resources;

import java.util.List;

import com.cognizant.offers.model.Transaction;
import com.cognizant.offers.service.ElgibilityService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class OfferElgibilityController {

	@Autowired
	ElgibilityService elgibilityService;

	@PostMapping("/transactions")
	List<Transaction> verigyTransactions(@RequestBody List<Transaction> transactions) {
		return elgibilityService.checkEligibilOffer(transactions);
	}
}
