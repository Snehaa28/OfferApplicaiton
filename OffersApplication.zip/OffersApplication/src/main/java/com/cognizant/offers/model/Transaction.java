package com.cognizant.offers.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document("offers")
@Data
public class Transaction {

	@Id
	private String id;
	private double amount;
	private String transactionId;

}
