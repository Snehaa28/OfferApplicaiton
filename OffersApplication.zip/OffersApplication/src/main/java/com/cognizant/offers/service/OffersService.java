package com.cognizant.offers.service;

import java.util.List;
import java.util.Optional;

import com.cognizant.offers.model.Offers;
import com.cognizant.offers.repository.OffersRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OffersService {

	@Autowired
	OffersRepository repository;

	public List<Offers> getAllOffers() {
		return repository.findAll();
	}

	public Offers createNewOffer(Offers offer) {
		return repository.save(offer);
	}

	public Optional<Offers> getOfferDetailsById(String id) {
		return repository.findById(id);
	}

	public void deleteOffer(String id) {
		repository.deleteById(id);
		
	}

}
