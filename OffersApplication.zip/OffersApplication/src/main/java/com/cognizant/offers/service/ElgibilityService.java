package com.cognizant.offers.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.cognizant.offers.model.ElgibleTransactions;
import com.cognizant.offers.model.Offers;
import com.cognizant.offers.model.Transaction;
import com.cognizant.offers.repository.OfferEligibilityRepository;
import com.cognizant.offers.repository.OffersRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ElgibilityService {

	@Autowired
	OffersRepository offerRepo;
	@Autowired
	OfferEligibilityRepository offerEligibilityRepo;

	public List<ElgibleTransactions> checkEligibilOffer(List<Transaction> transactions) {

		return offerEligibilityRepo.saveAll(getElgibleTransactions(transactions, offerRepo.findAll()));

	}

	private List<ElgibleTransactions> getElgibleTransactions(List<Transaction> transactions, List<Offers> offers) {
		List<ElgibleTransactions> elgilbeTransactions = new ArrayList<>();

		for (Transaction transaction : transactions) {
			Offers maxOffer = offers.stream().filter(offer -> transaction.getAmount() >= offer.getPrice())
					.collect(Collectors.toList()).stream().max(Comparator.comparing(Offers::getPrice)).get();
			if (maxOffer != null) {
				elgilbeTransactions.add(prepareElgiblieTransaction(transaction, maxOffer));
			}
		}
		return elgilbeTransactions;
	}

	private ElgibleTransactions prepareElgiblieTransaction(Transaction t, Offers offer) {
		return new ElgibleTransactions(t.getTransactionId(), offer.getId(), true);
	}

}
