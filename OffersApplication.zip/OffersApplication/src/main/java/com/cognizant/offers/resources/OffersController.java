package com.cognizant.offers.resources;

import java.util.List;
import java.util.Optional;

import com.cognizant.offers.model.Offers;
import com.cognizant.offers.service.OffersService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OffersController {

	@Autowired
	OffersService service;

	@GetMapping("/offers")
	List<Offers> getOffers() {
		return service.getAllOffers();
	}

	@PostMapping("/offer")
	Offers newOffer(@RequestBody Offers offer) {
		return service.createNewOffer(offer);
	}

	@GetMapping("/offer/{id}")
	Optional<Offers> getOfferById(@PathVariable String id) {
		return service.getOfferDetailsById(id);
	}

	@DeleteMapping("/offers/{id}")
	void deleteOffer(@PathVariable String id) {
		service.deleteOffer(id);
	}

}
